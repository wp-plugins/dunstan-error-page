Tags: 404, error
Contributors:


HOW TO USE THE ERROR PAGE
====================

Upload afdn_error_page.php to your plugins directory. Upload 404.php to the directory containing your current theme. You will also need to point you servers 404 error page to point to index.php?error=404 if you haven't already done that. Activate the plugin, go to Options > Error Page. Fill in the information, click Update and your set to go!