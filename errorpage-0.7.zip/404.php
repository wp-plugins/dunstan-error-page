<?php

$referer = $_POST["referer"];
$badpage = $_POST["badpage"];

$name = $_POST["name"];
$email = $_POST["email"];
$comment = $_POST["comment"];

if($submit_quick)
{
	$message = "A 404 error was recieved by ".$_SERVER['REMOTE_ADDR']." on ". date("r", time()).".\n";
	$message .= "Referer: $referer\r\n";
	$message .= "Bad Page: $badpage\r\n";
	$message .= "User details: ".$_SERVER['HTTP_USER_AGENT']."\r\n";
	mail(get_option('admin_email'), '['.get_option("blogname").'] 404 Quick Error Report', $message);
	$reported = true;
}
elseif($submit_feedback)
{
	$message = "A 404 error was recieved by ".$_SERVER['REMOTE_ADDR']." on ". date("r", time()).".\n";
	$message .= "Referer: $referer\r\n";
	$message .= "Bad Page: $badpage\r\n";
	$message .= "User details: ".$_SERVER['HTTP_USER_AGENT']."\r\n";
	$message .= "Name: $name\r\n";
	$message .= "Email: $email\r\n";
	$message .= "Comment: $comment\r\n";
	mail(get_option('admin_email'), '['.get_option("blogname").'] 404 Error Report', $message);
	$reported = true;
}
else
{
	$reported = false;
}

?>



<?php get_header(); ?>



<?php
	$afdn_error_page = get_option("afdn_error_page");
	
	if($afdn_error_page["accessed"]=="redirect"){
      $httpReferer = $_GET['referer'];
      $requestURI = $_GET['requested'];

    }
    else{
      $httpReferer = $_SERVER['HTTP_REFERER'];
      $requestURI = $_SERVER['REQUEST_URI'];
    }
	
?>
	<div id="content" style = "padding: 20px">

				<?php if($reported){?>
							<h3>Thank you for submitting an error report.</h3>				
				<?php } ?>

				<p>For some reason, the page your trying to access doesn't exist. Hopefully the information below can be of some assistance - <?php echo $afdn_error_page["name"]; ?>. </p>

				<table border="0">
  <tr>
    <td valign="top" width = "50%">					<h2>Your options</h2>
					<ol>
						<li>Submit an <a href="#quick" title="Jump down to the error reports &#8595;">error report form</a> &#8595;</li>
						<li>Go to the <a href="/" title="Go to the blog homepage">homepage</a></li>
						<li>Read the last <?php echo $afdn_error_page["num_posts"]; ?> blogs &#8594;</li>
						<li>Search AndrewFerguson.NET &#8595;</li>
					</ol>
					<p>
						<!-- Search Google -->
						 <center>
							<?php include (TEMPLATEPATH . '/searchform.php'); ?>
						</center>
						<!-- Search Google -->
					</p>
</td>
    <td width="0" valign="top">					<h2>Last <?php echo $afdn_error_page["num_posts"]; ?> blog posts</h2>
					<ol>
						<?php get_archives('postbypost', $afdn_error_page["num_posts"], 'custom', '<li>', '</li>'); ?>
					</ol>
</td>
  </tr>
  <tr>
    <td width="50%" valign="top">					<h2>Quick error report</h2>
					<p>You can quickly report this missing page by clicking the button below <small>(it will reload this page and send Andrew an email with the relevant details attached)</small>.</p>
					<form method="post" action="index.php?error=404">
						<div>
							<input type="hidden" name="referer" value="<?PHP echo $httpReferer; ?>" />
							<input type="hidden" name="badpage" value="<?PHP echo $requestURI; ?>" />
						</div>
						<p><input type="submit" name="submit_quick" value="submit quick error report" <?php if($reported) echo "disabled"; ?> /></p>
					</form>
</td>
    <td width="50%" valign="top">					<h2>Feedback request</h2>
					<p>If you&#8217;d like some feedback about the content you are looking for, please fill in the form below and I&#8217;ll get back to you. <small>(The page you were after, and the referring page, will be sent automatically.)</small></p>
					<form method="post" action="index.php?error=404">
						<div>
							<input type="hidden" name="referer" value="<?PHP echo $httpReferer; ?>" />
							<input type="hidden" name="badpage" value="<?PHP echo $requestURI; ?>" />
						</div>						
						<p>
							<label for="name">Name:</label><br /><input type="text" id="name" name="name" size="30" <?php if($reported) echo "disabled"; ?> /><br />
							<label for="email">Email:</label><br /><input type="text" id="email" name="email" size="30" <?php if($reported) echo "disabled"; ?> /><br />
							<label for="comment">Comment:</label><br /><textarea id="comment" name="comment" cols="22" rows="5" <?php if($reported) echo "disabled"; ?> ></textarea>
						</p>						
						<p><input type="submit" name="submit_feedback" value="submit error report" <?php if($reported) echo "disabled"; ?> /></p>
					</form>
</td>
  </tr>
</table>


	</div>

<?php //get_sidebar(); ?>

<?php get_footer(); ?>
